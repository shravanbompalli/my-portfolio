import Link from "next/link"
import { ChevronLeft, Mail, Phone, MapPin, Instagram, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ContactPage() {
      <h2 className="text-2xl font-bold">Get in Touch</h2>
      <p className="mt-2 text-lg">Feel free to reach out for collaborations or inquiries.</p>
      <p className="mt-2"><Mail className="inline mr-2" /> Email: <a href="mailto:shravansaru@gmail.com" className="text-blue-500">shravansaru@gmail.com</a></p>
      <p className="mt-2"><Phone className="inline mr-2" /> Phone: <a href="tel:+918096313130" className="text-blue-500">8096313130</a></p>
      <p className="mt-2"><Instagram className="inline mr-2" /> Instagram: <a href="https://www.instagram.com/shravanbompalli/" target="_blank" className="text-blue-500">@shravanbompalli</a></p>
  return (
    <div className="min-h-screen py-12 px-4 md:px-8 max-w-7xl mx-auto">
      <Button asChild variant="ghost" className="mb-4">
        <Link href="/" className="flex items-center gap-2">
          <ChevronLeft className="h-4 w-4" />
          Back to Home
        </Link>
      </Button>

      <h1 className="text-4xl font-bold mb-6">Contact Me</h1>
      <p className="text-lg text-muted-foreground max-w-3xl mb-12">
        Have a project in mind or want to discuss a photography session? I'd love to hear from you! Fill out the form
        below or use my contact information to get in touch.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label htmlFor="firstName" className="text-sm font-medium">
                  First Name
                </label>
                <input
                  id="firstName"
                  className="w-full p-3 border rounded-md bg-background"
                  placeholder="Your first name"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="lastName" className="text-sm font-medium">
                  Last Name
                </label>
                <input
                  id="lastName"
                  className="w-full p-3 border rounded-md bg-background"
                  placeholder="Your last name"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  className="w-full p-3 border rounded-md bg-background"
                  placeholder="Your email address"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="phone" className="text-sm font-medium">
                  Phone
                </label>
                <input
                  id="phone"
                  type="tel"
                  className="w-full p-3 border rounded-md bg-background"
                  placeholder="Your phone number"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="subject" className="text-sm font-medium">
                Subject
              </label>
              <input
                id="subject"
                className="w-full p-3 border rounded-md bg-background"
                placeholder="What is this regarding?"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="message" className="text-sm font-medium">
                Message
              </label>
              <textarea
                id="message"
                rows={6}
                className="w-full p-3 border rounded-md bg-background resize-none"
                placeholder="Tell me about your project or inquiry..."
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="service" className="text-sm font-medium">
                Service Interested In
              </label>
              <select id="service" className="w-full p-3 border rounded-md bg-background">
                <option value="">Select a service</option>
                <option value="wedding">Wedding Photography</option>
                <option value="portrait">Portrait Photography</option>
                <option value="event">Event Photography</option>
                <option value="commercial">Commercial Photography</option>
                <option value="other">Other</option>
              </select>
            </div>
            <Button type="submit" className="w-full">
              Send Message
            </Button>
          </form>
        </div>

        <div className="lg:col-span-1 space-y-8">
          <div className="bg-card p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-6">Contact Information</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <Mail className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-medium">Email</h3>
                  <p className="text-muted-foreground">jane@doephotography.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Phone className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-medium">Phone</h3>
                  <p className="text-muted-foreground">(123) 456-7890</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <MapPin className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-medium">Location</h3>
                  <p className="text-muted-foreground">New York City, NY</p>
                  <p className="text-muted-foreground">Available for travel worldwide</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Instagram className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-medium">Instagram</h3>
                  <a href="#" className="text-muted-foreground hover:text-primary">
                    @janedoephotography
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-6">Business Hours</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <Clock className="h-5 w-5 text-primary mt-1" />
                <div className="space-y-2">
                  <div>
                    <h3 className="font-medium">Monday - Friday</h3>
                    <p className="text-muted-foreground">9:00 AM - 6:00 PM</p>
                  </div>
                  <div>
                    <h3 className="font-medium">Saturday</h3>
                    <p className="text-muted-foreground">10:00 AM - 4:00 PM</p>
                  </div>
                  <div>
                    <h3 className="font-medium">Sunday</h3>
                    <p className="text-muted-foreground">Closed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-primary/10 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">Quick Response</h2>
            <p className="text-muted-foreground">
              I typically respond to all inquiries within 24-48 hours. For urgent matters, please call my phone number
              directly.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

