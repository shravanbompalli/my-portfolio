import Link from "next/link"
import Image from "next/image"
import { ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function GalleryPage() {
  // Categories of photography
  const categories = [
    { id: "candids", name: "Candids" },
    { id: "favorites", name: "My Favorites" },
    { id: "landscapes", name: "Landscapes" },
    { id: "events", name: "Events" },
    { id: "street", name: "Street Photography" },
  ];
    { id: "all", name: "All" },
    { id: "weddings", name: "Weddings" },
    { id: "portraits", name: "Portraits" },
    { id: "landscapes", name: "Landscapes" },
    { id: "events", name: "Events" },
  ]

  // Gallery images (would be fetched from a database in a real application)
  const galleryImages = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    src: `/placeholder.svg?height=800&width=1200`,
    alt: `Gallery image ${i + 1}`,
    category: categories[Math.floor(Math.random() * categories.length)].id,
  }))

  return (
    <div className="min-h-screen py-12 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <Button asChild variant="ghost" className="mb-4">
          <Link href="/" className="flex items-center gap-2">
            <ChevronLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
        <h1 className="text-4xl font-bold mb-6">Photography Gallery</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          Browse through my collection of photographs capturing special moments, beautiful landscapes, and compelling
          portraits.
        </p>
      </div>

      {/* Category Filter */}
      <div className="mb-12">
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button key={category.id} variant="outline" className="rounded-full">
              {category.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Gallery Grid - Masonry style */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {galleryImages.map((image) => (
          <div
            key={image.id}
            className="group relative overflow-hidden rounded-lg"
            style={{ height: `${Math.floor(Math.random() * 200) + 300}px` }}
          >
            <Image
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <Button variant="outline" className="text-white border-white hover:bg-white/20 hover:text-white">
                View Full Size
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-12 flex justify-center">
        <div className="flex gap-2">
          <Button variant="outline" disabled>
            Previous
          </Button>
          <Button variant="outline">1</Button>
          <Button variant="outline">2</Button>
          <Button variant="outline">3</Button>
          <Button variant="outline">Next</Button>
        </div>
      </div>
    </div>
  )
}

