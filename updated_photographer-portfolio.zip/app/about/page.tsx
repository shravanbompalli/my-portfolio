import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, Camera, Award, Users } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
      <h1 className="text-3xl font-bold">Shravan Bompalli</h1>
      <p className="mt-4 text-lg">I am a passionate cinematographer and candid photographer. I believe in the power of visuals to tell stories beyond words. Through my lens, I capture emotions, freeze moments, and create timeless frames. Every frame I shoot is a vision brought to life—because I trust my visuals, and so should you.</p>
  return (
    <div className="min-h-screen py-12 px-4 md:px-8 max-w-7xl mx-auto">
      <Button asChild variant="ghost" className="mb-4">
        <Link href="/" className="flex items-center gap-2">
          <ChevronLeft className="h-4 w-4" />
          Back to Home
        </Link>
      </Button>

      {/* About Hero */}
      <div className="flex flex-col md:flex-row gap-12 items-center mb-16">
        <div className="md:w-1/2">
          <h1 className="text-4xl font-bold mb-6">About Jane Doe</h1>
          <p className="text-lg mb-4">
            I'm a professional photographer with a passion for capturing authentic moments and telling stories through
            my lens.
          </p>
          <p className="text-lg mb-4">
            With over 10 years of experience in the field, I've had the privilege of working with amazing clients across
            the globe, from intimate weddings in Tuscany to corporate events in Tokyo.
          </p>
          <p className="text-lg">
            My approach to photography is deeply personal. I believe that the best images come from genuine connections
            and understanding the unique story behind each subject or event I photograph.
          </p>
        </div>
        <div className="md:w-1/2">
          <Image
            src="/placeholder.svg?height=800&width=800"
            alt="Jane Doe - Photographer"
            width={500}
            height={500}
            className="rounded-lg object-cover"
          />
        </div>
      </div>

      {/* My Journey */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold mb-8">My Journey</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-card p-6 rounded-lg shadow-sm">
            <div className="mb-4 bg-primary/10 p-3 rounded-full w-fit">
              <Camera className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">How It Started</h3>
            <p className="text-muted-foreground">
              My photography journey began when I was 16 years old, when my father gifted me my first DSLR camera. What
              started as a hobby quickly evolved into a lifelong passion.
            </p>
          </div>
          <div className="bg-card p-6 rounded-lg shadow-sm">
            <div className="mb-4 bg-primary/10 p-3 rounded-full w-fit">
              <Award className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Education & Awards</h3>
            <p className="text-muted-foreground">
              I studied Fine Arts Photography at the New York Institute of Photography and have been honored with
              several industry awards, including the International Photography Award in 2021.
            </p>
          </div>
          <div className="bg-card p-6 rounded-lg shadow-sm">
            <div className="mb-4 bg-primary/10 p-3 rounded-full w-fit">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">My Approach</h3>
            <p className="text-muted-foreground">
              I believe in creating a comfortable environment for my clients. My shooting style is a blend of directed
              and candid photography, ensuring natural and authentic results.
            </p>
          </div>
        </div>
      </section>

      {/* Equipment */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold mb-8">My Equipment</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Cameras</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li>• Canon EOS R5</li>
              <li>• Sony Alpha a7 III</li>
              <li>• Fujifilm X-T4 (for street photography)</li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Lenses</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li>• Canon RF 24-70mm f/2.8L IS USM</li>
              <li>• Canon RF 70-200mm f/2.8L IS USM</li>
              <li>• Canon RF 85mm f/1.2L USM</li>
              <li>• Sony FE 16-35mm f/2.8 GM</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Client Testimonials</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            {
              name: "Sarah & Michael",
              role: "Wedding Clients",
              quote:
                "Jane captured our wedding day perfectly. Her ability to document both the big moments and the small details exceeded our expectations. The photos truly tell the story of our special day.",
            },
            {
              name: "David Chen",
              role: "Corporate Client",
              quote:
                "Working with Jane for our company event was a pleasure. She was professional, unobtrusive, and delivered stunning images that we've used across our marketing materials.",
            },
            {
              name: "The Johnson Family",
              role: "Family Portrait Clients",
              quote:
                "Jane has a special talent for making everyone feel comfortable in front of the camera. Our family portraits are natural and beautiful - exactly what we wanted.",
            },
            {
              name: "Emily Rodriguez",
              role: "Portrait Client",
              quote:
                "I was nervous about my professional headshots, but Jane made the experience enjoyable. The results were amazing and have significantly upgraded my professional presence.",
            },
          ].map((testimonial, index) => (
            <div key={index} className="bg-muted p-6 rounded-lg">
              <p className="italic mb-4">"{testimonial.quote}"</p>
              <div>
                <p className="font-semibold">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center py-12 px-4 bg-muted rounded-lg">
        <h2 className="text-3xl font-bold mb-4">Ready to Work Together?</h2>
        <p className="text-lg max-w-2xl mx-auto mb-8">
          I'd love to discuss your photography needs and how we can create something beautiful together.
        </p>
        <Button asChild size="lg">
          <Link href="/contact">Get in Touch</Link>
        </Button>
      </section>
    </div>
  )
}

