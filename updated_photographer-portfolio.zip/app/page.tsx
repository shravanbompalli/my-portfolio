import Link from "next/link"
import Image from "next/image"
import { Instagram, Mail, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[90vh] w-full">
        <Image
          src="/placeholder.svg?height=1080&width=1920"
          alt="Featured photograph"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-4">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">Jane Doe Photography</h1>
          <p className="text-xl md:text-2xl max-w-2xl text-center mb-8">Capturing moments that last a lifetime</p>
          <Button asChild size="lg" className="rounded-full">
            <Link href="#gallery">View Gallery</Link>
          </Button>
        </div>
      </section>

      {/* Gallery Preview */}
      <section id="gallery" className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">Featured Work</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((item) => (
            <div key={item} className="group relative overflow-hidden rounded-lg">
              <Image
                src={`/placeholder.svg?height=600&width=800`}
                alt={`Gallery image ${item}`}
                width={800}
                height={600}
                className="w-full h-[300px] object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <Button variant="outline" className="text-white border-white hover:bg-white/20 hover:text-white">
                  View
                </Button>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
          <Button asChild variant="outline" size="lg">
            <Link href="/gallery">View All Work</Link>
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-4 md:px-8 bg-muted">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row gap-12 items-center">
          <div className="md:w-1/3">
            <Image
              src="/placeholder.svg?height=600&width=600"
              alt="Photographer portrait"
              width={400}
              height={400}
              className="rounded-full aspect-square object-cover"
            />
          </div>
          <div className="md:w-2/3">
            <h2 className="text-3xl font-bold mb-6">About Me</h2>
            <p className="text-lg mb-4">
              Hello! I'm Jane, a professional photographer based in New York City with over 10 years of experience
              capturing life's most precious moments.
            </p>
            <p className="text-lg mb-4">
              My passion for photography began when I was a teenager, and I've since developed a style that blends
              artistic composition with authentic emotion. I specialize in portrait, wedding, and landscape photography.
            </p>
            <p className="text-lg mb-6">
              When I'm not behind the camera, you can find me hiking in nature, exploring new coffee shops, or spending
              time with my family and our golden retriever, Max.
            </p>
            <Button asChild>
              <Link href="/about">Learn More</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: "Weddings", description: "Capturing your special day with elegance and emotion." },
            { title: "Portraits", description: "Professional portraits that showcase your unique personality." },
            { title: "Events", description: "Documenting your important events with attention to detail." },
          ].map((service, index) => (
            <div key={index} className="bg-card p-8 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-4">{service.title}</h3>
              <p className="text-muted-foreground mb-6">{service.description}</p>
              <Button variant="outline" size="sm">
                Learn More
              </Button>
            </div>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-4 md:px-8 bg-muted">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">Get In Touch</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-semibold mb-4">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-primary" />
                  <span>jane@doephotography.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>New York City, NY</span>
                </div>
                <div className="flex items-center gap-3">
                  <Instagram className="h-5 w-5 text-primary" />
                  <a href="#" className="hover:underline">
                    @janedoephotography
                  </a>
                </div>
              </div>
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4">Follow Me</h3>
                <div className="flex gap-4">
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Instagram className="h-5 w-5" />
                    <span className="sr-only">Instagram</span>
                  </Button>
                </div>
              </div>
            </div>
            <div>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <input id="name" className="w-full p-3 border rounded-md bg-background" placeholder="Your name" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="w-full p-3 border rounded-md bg-background"
                      placeholder="Your email"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium">
                    Subject
                  </label>
                  <input id="subject" className="w-full p-3 border rounded-md bg-background" placeholder="Subject" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full p-3 border rounded-md bg-background resize-none"
                    placeholder="Your message"
                  />
                </div>
                <Button type="submit" className="w-full">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold">Jane Doe Photography</h2>
          </div>
          <nav>
            <ul className="flex gap-6">
              <li>
                <Link href="/" className="hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/gallery" className="hover:text-primary">
                  Gallery
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-primary">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-primary">
                  Contact
                </Link>
              </li>
            </ul>
          </nav>
          <div className="mt-4 md:mt-0 text-sm text-muted-foreground">
            © {new Date().getFullYear()} Jane Doe Photography. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}

